using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moves : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void PawnMoves(GameObject currentTile)
    {
        // mogelijk moves
        Vector3 offsetNormalmove = new Vector3(1,0,0);
        Vector3 offsetStartermove = new Vector3(2, 0, 0);
        Vector3 offsetEnemyLeftMove = new Vector3(1, 0, 1);
        Vector3 offsetEnemyRightMove = new Vector3(1, 0, -1);

        Vector3 directionNormal = (currentTile.transform.position + offsetNormalmove) - Camera.main.transform.position ;

        if (Physics.Raycast(Camera.main.transform.position, directionNormal, out RaycastHit infoNormalMove)) // repeat voor andere posities
        {
            GameObject hitItem = infoNormalMove.collider.gameObject;

            if (hitItem.tag == "Tile")
            {
                hitItem.GetComponent<Tile>().SetSelectedMaterial();
            }
        }

    }


}
