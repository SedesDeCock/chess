using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Piece : MonoBehaviour
{
    [SerializeField]
    private Material _selectedMaterial;
    private Material _previousHitPieceMaterial;
    private GameObject _previousHitPawn;
    private GameObject _hitTile;

    private moves _moves;

    private float _maxTimer = 0.5f;
    private float _counter;

    private bool _whitTurn = true;


    void Update()
    {
        if (_counter > _maxTimer)
        {
            if (Input.GetButton("Fire1") == true)
            {
                Debug.Log("fire");
                _counter = 0;
                Vector3 t = Input.mousePosition;
                t.z = Camera.main.transform.position.y;

                Vector3 mouse = Camera.main.ScreenToWorldPoint(t);

                if (Physics.Raycast(Camera.main.transform.position, (mouse - Camera.main.transform.position), out RaycastHit info))
                {
                    Debug.Log("ReySucces");

                    GameObject hitItem = info.collider.gameObject;

                    string white = "WhitePiece";
                    string black = "BlackPiece";
                    string currentColor = white;

                    if (_whitTurn)
                    {
                        currentColor = white;
                    }
                    else
                    {
                        currentColor = black;
                    }

                    if (hitItem.tag == currentColor)
                    {

                        if (_previousHitPawn != null)
                        {
                            _previousHitPawn.GetComponent<MeshRenderer>().material = _previousHitPieceMaterial;
                        }

                        _hitTile = null;
                        _previousHitPawn = hitItem;
                        _previousHitPieceMaterial = hitItem.GetComponent<MeshRenderer>().material;
                        hitItem.GetComponent<MeshRenderer>().material = _selectedMaterial;
                    } //piece raken
                    if (hitItem.tag == "Tile")
                    {
                        _hitTile = hitItem;
                    }



                }
            } //1st
        }

        if (_previousHitPawn != null)
        {
            //_moves.PawnMoves( hierin pozitie van current pawn ); working progress

            GameObject[] Tile = GameObject.FindGameObjectsWithTag("Tile");

            foreach (GameObject obj in Tile)
            {
                obj.GetComponent<Tile>().SetSelectedMaterial();
            }



            if (_hitTile != null)
            {

                if (_hitTile.GetComponent<MeshRenderer>().material = _selectedMaterial)
                {
                    _previousHitPawn.transform.position = _hitTile.GetComponent<Tile>().GiveLocation();
                    _previousHitPawn.GetComponent<MeshRenderer>().material = _previousHitPieceMaterial;
                    _previousHitPawn = null;
                    _hitTile = null;
                    _whitTurn = !_whitTurn;
                }
            }


        } //jump pion naar nieuwe positie


        if (_previousHitPawn == null)
        {
            GameObject[] Tile = GameObject.FindGameObjectsWithTag("Tile");

            foreach (GameObject obj in Tile)
            {
                obj.GetComponent<Tile>().SetBackToOriginalmaterial();
            }
        } //zet alle vakje terug naar default kleur nadat je moved

        _counter += Time.deltaTime;

    }
}

