using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tile : MonoBehaviour
{
    private bool _isBlack = true;
    private Material _originalMaterial;
    [SerializeField]
    private Material _selectedMaterial;
    private MeshRenderer _renderer;
    [SerializeField]
    GameObject _movePosition;
    
   
    void Start()
    {
        _renderer = gameObject.GetComponent<MeshRenderer>();
        _originalMaterial = _renderer.material;
    }


    void Update()
    {
        
    }
    public void SetBackToOriginalmaterial()
    {
        _renderer.material = _originalMaterial;
    }
    public void SetSelectedMaterial()
    {
        _renderer.material = _selectedMaterial;
    }
    public Vector3 GiveLocation()
    {
        return _movePosition.transform.position;
    }
}
